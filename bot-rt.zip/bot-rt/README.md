<p align="center">
<img src="https://raw.githubusercontent.com/A187ID/AR15BOT/main/temp/A187.jpg" width="230" height="230"/>
</p>
<p align="center">
<a href="#"><img title="👾AR15BOT👾" src="https://img.shields.io/badge/AR15BOT-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://github.com/A187ID"><img title="Author" src="https://img.shields.io/badge/AUTHOR-ARIS187 ID-orange.svg?style=for-the-badge&logo=github"></a>
</p>
<p align="center">
<a href="https://www.codefactor.io/repository/github/A187ID/AR15BOT"><img title="Rating" src="https://www.codefactor.io/repository/github/A187ID/AR15BOT/badge/main"></a>
</p>
<p align="center">
<a href="https://github.com/A187ID/AR15BOT/followers"><img title="Followers" src="https://img.shields.io/github/followers/A187ID?color=blue&style=flat-square"></a>
<a href="https://github.com/A187ID/AR15BOT/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/A187ID/AR15BOT?color=red&style=flat-square"></a>
<a href="https://github.com/A187ID/AR15BOT/network/members"><img title="Forks" src="https://img.shields.io/github/forks/A187ID/AR15BOT?color=red&style=flat-square"></a>
<a href="https://github.com/A187ID/AR15BOT/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/A187ID/AR15BOT?label=Watchers&color=blue&style=flat-square"></a>
<a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2FA187ID%2FAR15BOT&count_bg=%2379C83D&title_bg=%23555555&icon=probot.svg&icon_color=%2300FF6D&title=hits&edge_flat=false"/></a>
</p>
<div align="center">
<details>
 
</details>

### WARNING
MAU RE-UPLOAD SCRIPT? KASIH NAMA/LINK CHANEL SAYA.... DILARANG UBAH INFO!!!

## NOTE:> 
SCRIPTNYA JANGAN DI JUAL/BELI KAN.. SCRIPT INI 100% GRATIS BUAT KALIAN PENGGUNA TERMUX
</div>

### Alat Dan Bahan
Siapin alat dan bahannya.
```bash
> niat
> 2 handphone (1 buat jalanin sc, 1 buat scan kode qr kak)
> jaringan internet kenceng,kuota+
> penyimpanan yang memadai
> aplikasi whatsapp
> aplikasi termux
> kopi+rokok ;v
```

### Cara Installnya
Script ini di modifikasi sama saya sendiri Aris187 ID.
```bash
> kalo lu belum punya apk termux, download di playstore
> masuk ke apk termux lalu ketik dibawah ini!
> termux-setup-storage
> pkg install git && pkg install wget && pkg install ffmpeg && pkg install nodejs
> apt update && apt upgrade
> git clone https://github.com/A187ID/AR15BOT
> cd AR15BOT
> npm i -g cwebp && npm i -g ytdl && npm i  && npm i got && node index js
> Tinggal scan kode qr yeee...done
```

## Features

| AR15BOT      |                   Feature        |
| :-----------: | :------------------------------: |
|       ✅       | Sticker Creator                  |
|       ✅       | Nulis                            |
|       ✅       | Covid (new)                      |
|       ✅       | Alay (new)                       |
|       ✅       | Lirik (new)                      |
|       ✅       | Foto Anime                       |
|       ✅       | Foto cewek/cowok (new)           |
|       ✅       | Pantun                           |
|       ✅       | Youtube Downloader               |
|       ✅       | Quotes                           |
|       ✅       | Nama (new)                       |
|       ✅       | Foto Anime                       |
|       ✅       | Pasangan (new)                   |
|       ✅       | Sholat (new )                    |
|       ✅       | Suara Google (fix)               |
|       ✅       | Quran                            |
|       ✅       | Youtube MP3 Downloader           |
|       ✅       | Intagram Downloader              |
|       ✅       | Twitter Downloader               |
|       ✅       | Facebook Downloader              |
|       ✅       | TikTok Downloader  (new)         |
|       ✅       | Wikipedia                        |
|       ✅       | Say                              |
|       ✅       | Toxic (new)                      |
|       ✅       | loli                             |
|       ✅       | hentai                           |
|       ✅       | Owner (new)                      |
|       ✅       | kata bijak                       |
|       ✅       | Fakta                            |
|       ✅       | Pokemon                          |
|       ✅       | Info                             |
|       ✅       | Donate                           |
|       ✅       | 18+.                             |
|                   MORE  Fitur                     |

Ket: Aktiv 24 jam

## Donasi
* [`Donasi 👾BOT👾`](gopay: 0895-6018-91104)


## Sosial Media Admin
* [`Youtube Admin`](belum ada)
* [`Instagram Admin`](https://instagram.com/adamrais.h)
* [`WhatsApp Admin `](https://wa.me/+6285277030729)
## THANKS TO
* [`fdciabdul`](https://github.com/fdciabdul/termux-whatsapp-bot)

* [`ArugaZ`](https://github.com/ArugaZ/whatsapp-bot)
* [`MhankBarBar`](https://github.com/MhankBarBar/whatsapp-bot)
* [`Alfbot`](https://github.com/alfiansx/alfbot)
